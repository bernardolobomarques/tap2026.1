package cleancode;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Sistema {

    Scanner sc = new Scanner(System.in);
    List<Pedido> pedidos = new ArrayList<>();
    Db db = new Db();

    public void executarMenu() {
        int operacao = -1;

        while (operacao != 0) {
            System.out.println("==== SISTEMA ====");
            System.out.println("1 - Novo pedido");
            System.out.println("2 - Listar pedidos");
            System.out.println("3 - Buscar pedido por id");
            System.out.println("4 - Relatorio");
            System.out.println("5 - Cancelar pedido");
            System.out.println("0 - Sair");
            System.out.print("Opcao: ");

            try {
                operacao = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("erro");
                operacao = -1;
            }

            if (operacao == 1) {
                novoPedido();
            } else if (operacao == 2) {
                listarPedidos();
            } else if (operacao == 3) {
                buscarPedidos();
            } else if (operacao == 4) {
                chamarRelatorio();
            } else if (operacao == 5) {
                cancelarPedido();
            } else if (operacao == 0) {
                System.out.println("fim");
            } else {
                System.out.println("opcao invalida");
            }
        }
    }

    public void novoPedido() {
        System.out.println("Nome cliente:");
        String nomeCliente = sc.nextLine();

        System.out.println("Tipo cliente (1 comum, 2 premium, 3 vip):");
        int tipoCliente;
        try {
            tipoCliente = Integer.parseInt(sc.nextLine());
        } catch (Exception e) {
            System.out.println("tipo errado, vai comum");
            tipoCliente = 1;
        }

        Cliente cliente = new Cliente();
        cliente.id = pedidos.size() + 1;
        cliente.nome = nomeCliente;
        cliente.tipo = tipoCliente;
        cliente.email = nomeCliente.replace(" ", "").toLowerCase() + "@email.com";

        Pedido pedido = new Pedido();
        pedido.id = pedidos.size() + 1;
        pedido.cliente = cliente;
        pedido.status = "NOVO";
        pedido.itens = new ArrayList<>();

        String continua = "s";
        while (continua.equalsIgnoreCase("s")) {
            System.out.println("Nome item:");
            String proximoItem = sc.nextLine();

            System.out.println("Preco item:");
            double precoItem;
            try {
                precoItem = Double.parseDouble(sc.nextLine());
            } catch (Exception e) {
                precoItem = 0;
            }

            System.out.println("Qtd:");
            int quantidadeItens;
            try {
                quantidadeItens = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                quantidadeItens = 1;
            }

            Item item = new Item();
            item.nome = proximoItem;
            item.preco = precoItem;
            item.qtd = quantidadeItens;
            pedido.itens.add(item);

            System.out.println("Adicionar mais item? s/n");
            continua = sc.nextLine();
        }

        double total = 0;
        for(Item item : pedido.itens) {
            total = total + (item.preco * item.qtd);
        }

        double desconto = 0;

        if (cliente.tipo == 1 && total > 300) {
            desconto = 0.05;
        }
        else if (cliente.tipo == 2 && total > 200) {
            desconto = 0.1;
        }
        else if (cliente.tipo == 3) {
            desconto = 0.15;
        }

        total = total - (total * desconto);

        // frete
        if (total < 100) {
            total = total + 25;
        } else if (total >= 100 && total < 300) {
            total = total + 15;
        }

        pedido.total = total;

        pedidos.add(pedido);
        db.save(pedido);

        System.out.println("Pedido criado com sucesso");
        System.out.println("Id: " + pedido.id);
        System.out.println("Cliente: " + pedido.cliente.nome);
        System.out.println("Total: " + pedido.total);

        if (pedido.total > 500) {
            System.out.println("Pedido importante!!!");
        }
    }

    public void listarPedidos() {
        if (pedidos.isEmpty()) {
            System.out.println("sem pedidos");
        } else {
            for (Pedido p : pedidos) {
                System.out.println("---------------");
                System.out.println("id: " + p.id);
                System.out.println("cliente: " + p.cliente.nome);
                System.out.println("email: " + p.cliente.email);
                System.out.println("tipo: " + p.cliente.tipo);
                System.out.println("status: " + p.status);
                System.out.println("total: " + p.total);
                System.out.println("itens:");
                for (int j = 0; j < p.itens.size(); j++) {
                    Item it = p.itens.get(j);
                    System.out.println(it.nome + " - " + it.qtd + " - " + it.preco);
                }
            }
        }
    }

    public void buscarPedidos() {
        System.out.println("Digite o id:");
        int id = Integer.parseInt(sc.nextLine());
        boolean achou = false;

        for (Pedido p : pedidos) {
            if (p.id == id) {
                achou = true;
                System.out.println("Pedido encontrado");
                System.out.println("id: " + p.id);
                System.out.println("cliente: " + p.cliente.nome);
                System.out.println("status: " + p.status);
                System.out.println("total: " + p.total);

                double subtotal = 0;
                for (int j = 0; j < p.itens.size(); j++) {
                    subtotal = subtotal + (p.itens.get(j).preco * p.itens.get(j).qtd);
                }
                System.out.println("subtotal calculado novamente: " + subtotal);

                if (p.cliente.tipo == 1) {
                    System.out.println("cliente comum");
                } else if (p.cliente.tipo == 2) {
                    System.out.println("cliente premium");
                } else if (p.cliente.tipo == 3) {
                    System.out.println("cliente vip");
                } else {
                    System.out.println("cliente desconhecido");
                }

                for (int j = 0; j < p.itens.size(); j++) {
                    Item it = p.itens.get(j);
                    System.out.println("item " + (j + 1) + ": " + it.nome + " / " + it.qtd + " / " + it.preco);
                }
            }
        }

        if (!achou) {
            System.out.println("nao achou");
        }
    }

    public void chamarRelatorio() {
        Relatorio r = new Relatorio();
        r.gerar(pedidos);
    }

    public void cancelarPedido() {
        System.out.println("Digite id do pedido");
        int id = Integer.parseInt(sc.nextLine());

        for (Pedido pedido : pedidos) {
            if (pedido.id == id) {
                if (pedido.status.equals("CANCELADO")) {
                    System.out.println("ja cancelado");
                } else {
                    pedido.status = "CANCELADO";
                    System.out.println("cancelado");
                }
                return;
            }
        }

        System.out.println("pedido nao existe");
    }
}

